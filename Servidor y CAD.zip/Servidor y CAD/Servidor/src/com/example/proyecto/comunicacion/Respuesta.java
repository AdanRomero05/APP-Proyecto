package com.example.proyecto.comunicacion;

import java.io.Serializable;
import java.util.List;
import juegoPojos.Cliente;
import juegoPojos.Pedido;

public class Respuesta implements Serializable {

    private boolean exito;
    private String mensaje;
    private Cliente cliente;           // Cambio de Alumno a Cliente
    private List<Cliente> clientes;    // Cambio de List<Alumno> a List<Cliente>
    private List<Pedido> listaPedidos;

    // Constructor:
    public Respuesta(boolean exito, String mensaje, Cliente cliente, List<Cliente> clientes) {
        this.exito = exito;
        this.mensaje = mensaje;
        this.cliente = cliente;
        this.clientes = clientes;
    }

    public Respuesta() {
        // Constructor vacío
    }

    // Getters y Setters:
    public boolean isExito() {
        return exito;
    }

    public void setExito(boolean exito) {
        this.exito = exito;
    }
    
    public List<Pedido> getListaPedidos() {
        return listaPedidos;
    }

    public void setListaPedidos(List<Pedido> listaPedidos) {
        this.listaPedidos = listaPedidos;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public Cliente getCliente() {
        return cliente;   // Método para obtener un único cliente
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;  // Método para establecer un único cliente
    }

    public List<Cliente> getClientes() {
        return clientes;  // Método para obtener una lista de clientes
    }

    public void setClientes(List<Cliente> clientes) {
        this.clientes = clientes;  // Método para establecer la lista de clientes
    }

}
