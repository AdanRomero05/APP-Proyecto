package com.example.proyecto.comunicacion;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import juegocad.JuegoCad;
import juegoPojos.Cliente;
import juegoPojos.Detalle_Pedido;
import juegoPojos.Pedido;
import juegoPojos.ExcepcionJuego;

public class HiloCliente extends Thread {

    private Socket socket;

    public HiloCliente(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        ObjectInputStream ois = null;
        ObjectOutputStream oos = null;

        try {
            ois = new ObjectInputStream(socket.getInputStream());
            oos = new ObjectOutputStream(socket.getOutputStream());

            // Instancia del CAD
            JuegoCad cad = new JuegoCad();

            // Leer petición
            Peticion peticion = (Peticion) ois.readObject();
            Respuesta respuesta = new Respuesta();

            switch (peticion.getTipoOperacion()) {
                case CREATE:
                    cad.insertarCliente(peticion.getCliente());
                    respuesta.setExito(true);
                    respuesta.setMensaje("Cliente creado con éxito.");
                    break;

                case DELETE:
                    Cliente clienteParaEliminar = peticion.getCliente();
                    Integer idEliminar = null;

                    // Obtener el ID del cliente para eliminar, ya sea desde el objeto cliente o el idCliente en la petición
                    if (clienteParaEliminar != null && clienteParaEliminar.getClienteID() != null) {
                        idEliminar = clienteParaEliminar.getClienteID();
                    } else if (peticion.getIdCliente() > 0) {
                        idEliminar = peticion.getIdCliente();
                    }

                    if (idEliminar != null) {
                        try {
                            Integer registrosAfectados = cad.eliminarCliente(idEliminar);
                            if (registrosAfectados != null && registrosAfectados > 0) {
                                respuesta.setExito(true);
                                respuesta.setMensaje("Cliente eliminado correctamente.");
                            } else {
                                respuesta.setExito(false);
                                respuesta.setMensaje("No se encontró el cliente para eliminar.");
                            }
                        } catch (ExcepcionJuego e) {
                            respuesta.setExito(false);
                            respuesta.setMensaje(e.getMensajeUsuario());
                            // Opcional: registrar mensaje de error admin, SQL, etc. en logs
                            System.err.println("Error al eliminar cliente: " + e.getMensajeAdmin());
                            System.err.println("Sentencia SQL: " + e.getSentenciaSQL());
                        }
                    } else {
                        respuesta.setExito(false);
                        respuesta.setMensaje("ID de cliente inválido para eliminar.");
                    }
                    break;

                case UPDATE:
                    Cliente clienteActualizar = peticion.getCliente();
                    if (clienteActualizar != null && clienteActualizar.getClienteID() != null) {
                        try {
                            Integer registros = cad.actualizarCLiente(clienteActualizar.getClienteID(), clienteActualizar);
                            if (registros != null && registros > 0) {
                                respuesta.setExito(true);
                                respuesta.setMensaje("Cliente actualizado correctamente.");
                                respuesta.setCliente(clienteActualizar);
                            } else {
                                respuesta.setExito(false);
                                respuesta.setMensaje("No se pudo actualizar el cliente.");
                            }
                        } catch (ExcepcionJuego e) {
                            respuesta.setExito(false);
                            respuesta.setMensaje(e.getMensajeUsuario());
                            // Puedes agregar info extra para debugging/logging si quieres
                        }
                    } else {
                        respuesta.setExito(false);
                        respuesta.setMensaje("Datos incompletos para actualizar cliente.");
                    }
                    break;

                case READ:

                    break;

                case READ_ALL:
                    ArrayList<Cliente> lista = cad.leerClientes();
                    respuesta.setClientes(lista);
                    respuesta.setExito(true);
                    respuesta.setMensaje("Clientes recuperados correctamente.");
                    break;

                case PING:
                    respuesta.setExito(true);
                    respuesta.setMensaje("Ping exitoso.");
                    break;
                    
                // registro y Login:
                
                case REGISTER:
                    Cliente cliente2 = peticion.getCliente();
                    Integer idGenerado = cad.insertarCliente(cliente2);
                    if (idGenerado != null && idGenerado > 0) {
                        cliente2.setClienteID(idGenerado);
                        respuesta.setExito(true);
                        respuesta.setMensaje("Registro de cliente exitoso.");
                        respuesta.setCliente(cliente2);
                    } else {
                        respuesta.setExito(false);
                        respuesta.setMensaje("Error en el registro del cliente.");
                    }
                    break;
                
                case LOGIN:
                    if (peticion.getCorreoElectronico() != null && peticion.getPasswordPlano() != null) {
                        // Verificar en la base de datos si el cliente existe y la contraseña es correcta
                        Cliente cliente = cad.login(peticion.getCorreoElectronico(), peticion.getPasswordPlano());

                        if (cliente != null) {
                            respuesta.setExito(true);
                            respuesta.setMensaje("Login exitoso.");
                            respuesta.setCliente(cliente);  // Asegúrate de enviar el cliente en la respuesta
                        } else {
                            respuesta.setExito(false);
                            respuesta.setMensaje("Credenciales incorrectas.");
                        }
                    } else {
                        respuesta.setExito(false);
                        respuesta.setMensaje("No se ha enviado un cliente válido.");
                    }
                    break;
                
                case PEDIDO:
                    Pedido pedido = peticion.getPedido();
                    cad.insertarPedido(pedido);
                    respuesta.setExito(true);
                    respuesta.setMensaje("Pedido insertado con éxito.");   
                break;
                case GET_PEDIDOS_CLIENTE:
                    int idCliente = peticion.getIdCliente();
                    ArrayList<Pedido> pedidosCliente = cad.leerPedidosPorClienteId(idCliente);
                    respuesta.setListaPedidos(pedidosCliente);
                    respuesta.setExito(true);
                    respuesta.setMensaje("Pedidos obtenidos correctamente.");
                    break;

                case ELIMINAR_PEDIDO:
                    int idPedido = peticion.getPedidoID();
                    Integer registrosCancelados = cad.eliminarPedido(idPedido);
                    if (registrosCancelados != null && registrosCancelados > 0) {
                        respuesta.setExito(true);
                        respuesta.setMensaje("Pedido cancelado con éxito.");
                    } else {
                        respuesta.setExito(false);
                        respuesta.setMensaje("No se pudo cancelar el pedido.");
                    }
                    break;

                default:
                    respuesta.setExito(false);
                    respuesta.setMensaje("Operación no reconocida.");
            }

            // Enviar respuesta
            oos.writeObject(respuesta);
            oos.flush();

        } catch (IOException | ClassNotFoundException | ExcepcionJuego e) {
            e.printStackTrace();
        }  finally {
            try {
                if (ois != null) ois.close();
                if (oos != null) oos.close();
                if (socket != null) socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
