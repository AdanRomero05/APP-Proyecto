package com.example.proyecto.comunicacion;

import java.io.Serializable;
import java.util.List;
import juegoPojos.Cliente;
import juegoPojos.Detalle_Pedido;
import juegoPojos.Pedido;

public class Peticion implements Serializable {

    public enum TipoOperacion {
        CREATE,     // Crear un cliente
        READ,       // Obtener cliente por ID
        READ_ALL,   // Obtener todos los clientes
        UPDATE,     // Actualizar cliente
        DELETE,     // Eliminar cliente
        PING,       // Comprobar estado del servidor
        REGISTER,   // Registro de cliente (correo, contraseña)
        LOGIN,       // Login con correo y contraseña
        PEDIDO,
        GET_PEDIDOS_CLIENTE,
        ELIMINAR_PEDIDO
    }

    private TipoOperacion tipoOperacion;
    private Cliente cliente;
    private int idCliente;
    private Pedido pedido;
    private int pedidoID;
    private List<Pedido> listaPedidos;

    // Para LOGIN y REGISTER
    private String correoElectronico;  // Nuevo campo para login/registro
    private String passwordPlano;
    
    public Peticion() {
    // Constructor vacío
    }
    
    public Peticion(TipoOperacion tipoOperacion) {
        this.tipoOperacion = tipoOperacion;
    }
    
    public Pedido getPedido() {
        return pedido;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }
    
    public int getPedidoID() {
        return pedidoID;
    }

    public void setPedidoID(int pedidoID) {
        this.pedidoID = pedidoID;
    }
    
    public List<Pedido> getListaPedidos() {
        return listaPedidos;
    }

    public void setListaPedidos(List<Pedido> listaPedidos) {
        this.listaPedidos = listaPedidos;
    }
    
    public TipoOperacion getTipoOperacion() {
        return tipoOperacion;
    }

    public void setTipoOperacion(TipoOperacion tipoOperacion) {
        this.tipoOperacion = tipoOperacion;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getPasswordPlano() {
        return passwordPlano;
    }

    public void setPasswordPlano(String passwordPlano) {
        this.passwordPlano = passwordPlano;
    }
}
