/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juegocad;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import juegoPojos.Cliente;
import juegoPojos.ExcepcionJuego;
import juegoPojos.Pedido;
import org.mindrot.jbcrypt.BCrypt;

/**
 *
 * @author DAM217
 * Clase JuegoCad.
 * Clase encargada de gestionar las operaciones relacionadas con la base de datos 
 * para las entidades Cliente y Pedido.
 */
public class JuegoCad {
    
    // conexion:
    
    private String conexionBD = "jdbc:oracle:thin:@192.168.1.129:1521:test";
    private String usuario = "juego";
    private String contraseña = "kk";
    
    /**
     * Constructor de la clase JuegoCad.
     * Inicializa el controlador JDBC para Oracle.
     * 
     * @throws ExcepcionJuego Si no se encuentra el controlador de Oracle.
     */
    public JuegoCad() throws ExcepcionJuego {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");   
        } catch (ClassNotFoundException ex) {
            ExcepcionJuego e = new ExcepcionJuego();
            e.setMensajeUsuario("Error general del sistema. Consulte Admin");
            e.setMensajeAdmin(ex.getMessage());
            throw e;      
        }
    }
    
    // 1º - Cliente
  
    /**
     * Inserta un nuevo cliente en la base de datos.
     * Utiliza la secuencia `seqpedido` para generar automáticamente el ID del cliente.
     *
     * @param cliente El objeto Cliente a insertar.
     * @return El número de registros afectados.
     * @throws ExcepcionJuego Si ocurre un error de base de datos.
     */
    
    // Lo voy a transformar en REGISTRO:

    public Integer insertarCliente(Cliente cliente) throws ExcepcionJuego {
        Integer registrosAfectados = 0;
        String dml = "INSERT INTO CLIENTE (CLIENTE_ID, NOMBRE, APELLIDO, APELLIDO2, CONTRASENA, TELEFONO, EMAIL, LOCALIDAD, CIUDAD, CALLE, NUMERO) "
                     + "VALUES (seqcliente.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexion = DriverManager.getConnection(conexionBD, usuario, contraseña);
             PreparedStatement sentencia = conexion.prepareStatement(dml)) {

            // Generar el hash de la contraseña usando BCrypt
            String contrasenaHasheada = BCrypt.hashpw(cliente.getContrasena(), BCrypt.gensalt());

            // Asignar valores a los parámetros de la consulta, usando la contraseña hasheada
            sentencia.setString(1, cliente.getNombre());
            sentencia.setString(2, cliente.getApellido());
            sentencia.setString(3, cliente.getApellido2());
            sentencia.setString(4, contrasenaHasheada);  // Usamos la contraseña hasheada
            sentencia.setString(5, cliente.getTelefono());
            sentencia.setString(6, cliente.getEmail());
            sentencia.setString(7, cliente.getLocalidad());
            sentencia.setString(8, cliente.getCiudad());
            sentencia.setString(9, cliente.getCalle());
            sentencia.setObject(10, cliente.getNumero(), Types.INTEGER);

            registrosAfectados = sentencia.executeUpdate();
            System.out.println("Registros Afectados: " + registrosAfectados);

        } catch (SQLException ex) {
            // Manejo de excepciones
            ExcepcionJuego e = new ExcepcionJuego();
            e.setMensajeAdmin(ex.getMessage());
            e.setSentenciaSQL(dml);
            e.setCodigoErrorBD(ex.getErrorCode());

            switch (ex.getErrorCode()) {
                case 1062:
                    e.setMensajeUsuario("No se puede insertar el cliente, ya existe un cliente con ese ID.");
                    break;

                case 1452:
                    e.setMensajeUsuario("No se puede insertar el cliente porque viola una restricción de clave externa.");
                    break;

                case 12899:
                    e.setMensajeUsuario("El contenido de una fila es muy largo.");
                    break;

                default:
                    e.setMensajeUsuario("Error general del sistema, consulte con el administrador.");
            }

            throw e;
        }

        return registrosAfectados;
    }

    
    // lOGIN:
    public Cliente login(String correo, String passwordPlano) {
        try {
            String sql = "SELECT CLIENTE_ID, NOMBRE, APELLIDO, APELLIDO2, CONTRASENA, TELEFONO, EMAIL, LOCALIDAD, CIUDAD, CALLE, NUMERO FROM CLIENTE WHERE EMAIL = ?";
            try (Connection conexion = DriverManager.getConnection(conexionBD, usuario, contraseña);
                PreparedStatement sentencia = conexion.prepareStatement(sql)) {
                
                sentencia.setString(1, correo);
                ResultSet rs = sentencia.executeQuery();

                if (rs.next()) {
                    String storedHash = rs.getString("CONTRASENA");

                    if (BCrypt.checkpw(passwordPlano, storedHash)) {
                        Cliente cliente = new Cliente();
                        cliente.setClienteID(rs.getInt("CLIENTE_ID"));
                        cliente.setNombre(rs.getString("NOMBRE"));
                        cliente.setApellido(rs.getString("APELLIDO"));
                        cliente.setApellido2(rs.getString("APELLIDO2"));
                        cliente.setContrasena(passwordPlano); // Se devuelve en texto claro
                        cliente.setTelefono(rs.getString("TELEFONO"));
                        cliente.setEmail(rs.getString("EMAIL")); 
                        cliente.setLocalidad(rs.getString("LOCALIDAD"));
                        cliente.setCiudad(rs.getString("CIUDAD"));
                        cliente.setCalle(rs.getString("CALLE"));
                        cliente.setNumero(rs.getInt("NUMERO"));

                        return cliente;
                    }
                }
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }



    
    /**
     * Elimina un cliente de la base de datos.
     * 
     * @param clienteID El ID del cliente a eliminar.
     * @return El número de registros afectados.
     * @throws ExcepcionJuego Si el cliente tiene registros relacionados o se produce un error.
     */
    public Integer eliminarCliente(Integer clienteID) throws ExcepcionJuego{
        
        Integer registrosAfectados = 0;
        String dmlPedidos = "DELETE FROM PEDIDO WHERE CLIENTE_ID = " + clienteID;
        String dml = "delete from CLIENTE where CLIENTE_ID =" + clienteID;
        try {
           
            Connection conexion = DriverManager.getConnection(conexionBD,usuario, contraseña);
            Statement sentencia = conexion.createStatement();
            
            // Primero borrar pedidos asociados
            sentencia.executeUpdate(dmlPedidos);
           
            registrosAfectados = sentencia.executeUpdate(dml);
            System.out.println("Registros Afectados: " + registrosAfectados);
            
            System.out.println("----- Cerrando la Conexión a la BD");
            sentencia.close();
            conexion.close();
            
        } catch (SQLException ex) {
            
            ExcepcionJuego e = new ExcepcionJuego();
            e.setMensajeAdmin(ex.getMessage());
            e.setSentenciaSQL(dml);
            e.setCodigoErrorBD(ex.getErrorCode());
            
            switch(ex.getErrorCode()) {
                
                case 2292: e.setMensajeUsuario("EL cliente no se puede borrar por que tiene registros asignados");
                break;
                
                case 1452: e.setMensajeUsuario("No se puede eliminar este cliente porque está relacionado con otros registros.");
                break;
                
                default: e.setMensajeUsuario("Error general de sistema, consulte con el administrador");
            }
            
            throw e;
        }
        
        return registrosAfectados;
    }
    
    /**
     * Método que realiza la actualizacion de CLIENTE
     * @param clienteID Identificador de Cliente que se quiere modificar
     * @param cliente Objeto que contiene los valores de cliente y almacenara los nuevos valores.
     * @return Cantidad de registros actualizados, valores posibles: 0 (no se ha actualizado ningun cliente) o 1 (se ha actualizado)
     * @throws ExcepcionJuego Se lanzará esta excepcion cuando se produzca una violación de las constraints de la base de datos o la sentencia java.
    */
    public Integer actualizarCLiente(Integer clienteID, Cliente cliente) throws ExcepcionJuego{
    
        String contrasena = cliente.getContrasena();
        if (contrasena == null || contrasena.trim().isEmpty()) {

            throw new ExcepcionJuego();
        } else {
            // Comprobar si la contraseña ya está hasheada (ejemplo estándar con BCrypt)
            if (!contrasena.startsWith("$2a$")) {
                // No está hasheada, entonces la hasheamos
                String contrasenaHasheada = BCrypt.hashpw(contrasena, BCrypt.gensalt());
                cliente.setContrasena(contrasenaHasheada);
            }
            // Si ya empieza con $2a$, asumimos que es hash y no se vuelve a hashear
        }
    String dml = "UPDATE CLIENTE SET NOMBRE=?, APELLIDO=?, APELLIDO2=?, CONTRASENA=?, TELEFONO=?, EMAIL=?, LOCALIDAD=?, CIUDAD=?, CALLE=?, NUMERO=? WHERE CLIENTE_ID=?";
    int registrosAfectados = 0;
    
    try(Connection conexion = DriverManager.getConnection(conexionBD, usuario, contraseña);
        PreparedStatement sentenciaPreparada = conexion.prepareStatement(dml);) {

            sentenciaPreparada.setString(1, cliente.getNombre());
            sentenciaPreparada.setString(2, cliente.getApellido());
            sentenciaPreparada.setString(3, cliente.getApellido2());
            sentenciaPreparada.setString(4, cliente.getContrasena());
            sentenciaPreparada.setString(5, cliente.getTelefono());
            sentenciaPreparada.setString(6, cliente.getEmail());
            sentenciaPreparada.setString(7, cliente.getLocalidad());
            sentenciaPreparada.setString(8, cliente.getCiudad());
            sentenciaPreparada.setString(9, cliente.getCalle());
            sentenciaPreparada.setObject(10, cliente.getNumero(), Types.INTEGER);
            
            sentenciaPreparada.setObject(11, cliente.getClienteID(), Types.INTEGER);
            
            registrosAfectados = sentenciaPreparada.executeUpdate();
            sentenciaPreparada.close();
            conexion.close();
            
        } catch (SQLException ex) {
            
            ExcepcionJuego e = new ExcepcionJuego();
            e.setMensajeAdmin(ex.getMessage());
            e.setSentenciaSQL(dml);
            e.setCodigoErrorBD(ex.getErrorCode());
            
            switch(ex.getErrorCode()) {
                    
                case 1409:
                    
                    e.setMensajeUsuario("El NOMBRE, APELLIDO1, CONTRASEÑA, TELEFONO, EMAIL, LOCALIDAD, CIUDAD, CALLE Y NUMERO no pueden estar vacios");
                    break;
                
                case 2291: 
                
                    e.setMensajeUsuario("El campo seleccionado no existe en el sistema.");
                    break;
                
                case 2290:
                    
                    e.setMensajeUsuario("Uno de los valores ingresados no cumple con las restricciones establecidas para este campo.");
                    break;
                
                case 12899:
                    
                    e.setMensajeUsuario("Uno de los campos ingresados excede la longitud permitida.");
                    break;              
                    
                case 60:
                    
                    e.setMensajeUsuario("La base de datos se ha bloqueado, contacte al administrador.");
                    break;
                
                case 1040:
                    
                    e.setMensajeUsuario("Se ha alcanzado el límite de conexiones a la base de datos, intente más tarde.");
                    break;
                
                case 1064:
                    
                    e.setMensajeUsuario("Ocurrio un error en la sintaxis de la consulta, contacta con el administrador.");
                    break;
                    
                default:   e.setMensajeUsuario("Error general del sistema. Consulte Admin");
            }
            
            throw e;
            
        }
        return registrosAfectados;
    }
    
    /**
     * Recupera los datos de un cliente específico por su ID.
     * 
     * @param clienteID El ID del cliente a leer.
     * @return El objeto Cliente con los datos obtenidos.
     * @throws ExcepcionJuego Si ocurre un error en la operación de la base de datos.
     */
    public Cliente leerCliente(Integer clienteID) throws ExcepcionJuego{
        
    Cliente cliente = null;
    String dql = "select * from CLIENTE where CLIENTE_ID = ?";

    try {
        
        Connection conexion = DriverManager.getConnection(conexionBD, usuario, contraseña);

        PreparedStatement sentencia = conexion.prepareStatement(dql);
        sentencia.setObject(1, clienteID, Types.INTEGER);

        ResultSet resultado = sentencia.executeQuery();;

        if (resultado.next()) {
            
            cliente = new Cliente();
            
            cliente.setClienteID(resultado.getInt("CLIENTE_ID"));
            cliente.setNombre(resultado.getString("NOMBRE"));
            cliente.setApellido(resultado.getString("APELLIDO"));
            cliente.setApellido2(resultado.getString("APELLIDO2"));
            cliente.setContrasena(resultado.getString("CONTRASENA"));
            cliente.setTelefono(resultado.getString("TELEFONO"));
            cliente.setEmail(resultado.getString("EMAIL"));
            cliente.setLocalidad(resultado.getString("LOCALIDAD"));
            cliente.setCiudad(resultado.getString("CIUDAD"));
            cliente.setCalle(resultado.getString("CALLE"));
            cliente.setNumero(resultado.getInt("NUMERO"));
        }

        resultado.close();
        sentencia.close();
        conexion.close();

    } catch (SQLException ex) {
        
        ExcepcionJuego e = new ExcepcionJuego();
        e.setMensajeAdmin(ex.getMessage());
        e.setSentenciaSQL(dql);
        e.setCodigoErrorBD(ex.getErrorCode());
        e.setMensajeUsuario("No se ha podido leer Cliente.");
        throw e;
    }
    
    return cliente;
    
    }
    
    /**
     * Recupera todos los clientes almacenados en la base de datos.
     * 
     * @return Una lista de objetos Cliente con los datos obtenidos.
     * @throws ExcepcionJuego Si ocurre un error en la operación de la base de datos.
     */
    public ArrayList<Cliente> leerClientes() throws ExcepcionJuego{
        
        ArrayList<Cliente> listaClientes = new ArrayList<>();
        Cliente cliente;
        String dql = "select * from CLIENTE";
        
        try {
            
            Connection conexion = DriverManager.getConnection(conexionBD, usuario, contraseña);

            Statement sentencia = conexion.createStatement();
            ResultSet resultado = sentencia.executeQuery(dql);
            
            while (resultado.next()) {
                
                cliente = new Cliente();
                
                cliente.setClienteID(resultado.getInt("CLIENTE_ID"));
                cliente.setNombre(resultado.getString("NOMBRE"));
                cliente.setApellido(resultado.getString("APELLIDO"));
                cliente.setApellido2(resultado.getString("APELLIDO2"));
                cliente.setContrasena(resultado.getString("CONTRASENA"));
                cliente.setTelefono(resultado.getString("TELEFONO"));
                cliente.setEmail(resultado.getString("EMAIL"));
                cliente.setLocalidad(resultado.getString("LOCALIDAD"));
                cliente.setCiudad(resultado.getString("CIUDAD"));
                cliente.setCalle(resultado.getString("CALLE"));
                cliente.setNumero(resultado.getInt("NUMERO"));
                
                listaClientes.add(cliente);
                
            }
            
            resultado.close();
            sentencia.close();
            conexion.close();
            
        } catch (SQLException ex) {
            
            ExcepcionJuego e = new ExcepcionJuego();
            e.setMensajeAdmin(ex.getMessage());
            e.setSentenciaSQL(dql);
            e.setCodigoErrorBD(ex.getErrorCode());
            e.setMensajeUsuario("No se ha podido leer todos los clientes, consulte al administrador.");
            throw e;
        }
        return listaClientes;
    
    }
    
    /**
     * Inserta un nuevo pedido en la base de datos.
     * Utiliza la secuencia `seqpedido` para generar automáticamente el ID del pedido.
     * 
     * @param pedido El objeto Pedido a insertar.
     * @return El número de registros afectados.
     * @throws ExcepcionJuego Si ocurre un error de base de datos.
     */
    public Integer insertarPedido(Pedido pedido) throws ExcepcionJuego {
        
        Integer registrosAfectados = 0;
        String dml = "INSERT INTO PEDIDO (PEDIDO_ID, FECHA_PEDIDO, FECHA_ENTREGA, ESTADO, DETALLES, CLIENTE_ID) "
                   + "VALUES (seqpedido.NEXTVAL, ?, ?, ?, ?, ?)";

        try(Connection conexion = DriverManager.getConnection(conexionBD, usuario, contraseña);
            PreparedStatement sentencia = conexion.prepareStatement(dml)) { 

            // Fechas:
            sentencia.setDate(1, new java.sql.Date(pedido.getFecha_pedido().getTime()));
            sentencia.setDate(2, pedido.getFecha_entrega() != null ? new java.sql.Date(pedido.getFecha_entrega().getTime()) : null);
            sentencia.setString(3, pedido.getEstado());
            sentencia.setString(4, pedido.getDetalles());
            sentencia.setObject(5, pedido.getCliente().getClienteID(), Types.INTEGER);

            registrosAfectados = sentencia.executeUpdate();
            System.out.println("Registros Afectados: " + registrosAfectados);

        } catch (SQLException ex) {
            ExcepcionJuego e = new ExcepcionJuego();
            e.setMensajeAdmin(ex.getMessage());
            e.setSentenciaSQL(dml);
            e.setCodigoErrorBD(ex.getErrorCode());

            switch (ex.getErrorCode()) {
                case 1062:
                    e.setMensajeUsuario("No se puede insertar el pedido, ya existe un pedido con ese ID.");
                    break;
                case 1452:
                    e.setMensajeUsuario("No se puede insertar el pedido porque CLIENTE_ID no existe.");
                    break;
                case 2291:
                    e.setMensajeUsuario("Violación de restricción de clave foránea, revise los datos.");
                    break;
                default:
                    e.setMensajeUsuario("Error general del sistema, consulte con el administrador.");
                    break;
            }

            throw e;
        }

        return registrosAfectados;
    }
    
    
    
    /**
     * Elimina un pedido de la base de datos.
     * 
     * @param pedidoID El ID del pedido a eliminar.
     * @return El número de registros afectados.
     * @throws ExcepcionJuego Si ocurre un error de base de datos.
     */
    public Integer eliminarPedido(Integer pedidoID) throws ExcepcionJuego {
        
        Integer registrosAfectados = 0;
        String dml = "delete from PEDIDO where PEDIDO_ID = "+ pedidoID;

        try {
            
            Connection conexion = DriverManager.getConnection(conexionBD, usuario, contraseña);
            PreparedStatement sentencia = conexion.prepareStatement(dml);

            registrosAfectados = sentencia.executeUpdate();
            System.out.println("Registros Afectados: " + registrosAfectados);

            sentencia.close();
            conexion.close();

        } catch (SQLException ex) {

            ExcepcionJuego e = new ExcepcionJuego();
            e.setMensajeAdmin(ex.getMessage());
            e.setSentenciaSQL(dml);
            e.setCodigoErrorBD(ex.getErrorCode());

            switch(ex.getErrorCode()) {
                
                case 2292:
                    e.setMensajeUsuario("El pedido no se puede borrar porque tiene registros asignados.");
                    break;
                case 1452:
                    e.setMensajeUsuario("No se puede eliminar este pedido porque está relacionado con otros registros.");
                    break;
                default:
                    e.setMensajeUsuario("Error general de sistema, consulte con el administrador.");                 
            }
            throw e;
        }
        return registrosAfectados;
    }
    
    public ArrayList<Pedido> leerPedidosPorClienteId(int clienteId) throws ExcepcionJuego {
        
        ArrayList<Pedido> listaPedidos = new ArrayList<>();
        String dql = "SELECT p.PEDIDO_ID, p.FECHA_PEDIDO, p.FECHA_ENTREGA, p.ESTADO, p.DETALLES, "
                   + "c.CLIENTE_ID, c.NOMBRE "
                   + "FROM PEDIDO p "
                   + "JOIN CLIENTE c ON p.CLIENTE_ID = c.CLIENTE_ID "
                   + "WHERE c.CLIENTE_ID = ?";

        try (
            Connection conexion = DriverManager.getConnection(conexionBD, usuario, contraseña);
            PreparedStatement sentencia = conexion.prepareStatement(dql)
        ) {
            sentencia.setInt(1, clienteId);
            ResultSet resultado = sentencia.executeQuery();

            while (resultado.next()) {
                Pedido pedido = new Pedido();
                pedido.setPedidoID(resultado.getInt("PEDIDO_ID"));
                pedido.setFecha_pedido(resultado.getDate("FECHA_PEDIDO"));
                pedido.setFecha_entrega(resultado.getDate("FECHA_ENTREGA"));
                pedido.setEstado(resultado.getString("ESTADO"));
                pedido.setDetalles(resultado.getString("DETALLES"));

                Cliente cliente = new Cliente();
                cliente.setClienteID(resultado.getInt("CLIENTE_ID"));
                cliente.setNombre(resultado.getString("NOMBRE"));

                pedido.setCliente(cliente);
                listaPedidos.add(pedido);
            }

            resultado.close();

        } catch (SQLException ex) {
            ExcepcionJuego e = new ExcepcionJuego();
            e.setMensajeAdmin(ex.getMessage());
            e.setSentenciaSQL(dql);
            e.setCodigoErrorBD(ex.getErrorCode());
            e.setMensajeUsuario("Error al recuperar pedidos del cliente.");
            throw e;
        }

        return listaPedidos;
    }
    
    /**
     * Actualiza los datos de un pedido existente.
     * 
     * @param pedidoID El ID del pedido a actualizar.
     * @param pedido Los nuevos datos del pedido.
     * @return El número de registros afectados.
     * @throws ExcepcionJuego Si ocurre un error de base de datos.
     */
    public Integer actualizarPedido(Integer pedidoID, Pedido pedido) throws ExcepcionJuego {
    
    int registrosAfectados = 0; 
    String dml = "UPDATE PEDIDO SET FECHA_PEDIDO=?, FECHA_ENTREGA=?, ESTADO=?, DETALLES=?, CLIENTE_ID=? WHERE PEDIDO_ID=?";
    
    try(Connection conexion = DriverManager.getConnection(conexionBD, usuario, contraseña);
        PreparedStatement sentenciaPreparada = conexion.prepareStatement(dml)) {

        // Establecer los parámetros del PreparedStatement
        sentenciaPreparada.setDate(1, new java.sql.Date(pedido.getFecha_pedido().getTime()));
        sentenciaPreparada.setDate(2, pedido.getFecha_entrega() != null ? new java.sql.Date(pedido.getFecha_entrega().getTime()) : null);
        
        sentenciaPreparada.setString(3, pedido.getEstado());
        sentenciaPreparada.setString(4, pedido.getDetalles());
        sentenciaPreparada.setObject(5, pedido.getCliente().getClienteID(), Types.INTEGER);
        
        sentenciaPreparada.setObject(6, pedidoID, Types.INTEGER);

        registrosAfectados = sentenciaPreparada.executeUpdate();

        } catch (SQLException ex) {
            
            ExcepcionJuego e = new ExcepcionJuego();
            e.setMensajeAdmin(ex.getMessage());
            e.setSentenciaSQL(dml);
            e.setCodigoErrorBD(ex.getErrorCode());

            switch (ex.getErrorCode()) {
                
                case 1:
                    e.setMensajeUsuario("El identificador de pedido ya está en uso. Intente otro.");
                    break;

                case 1400:
                    e.setMensajeUsuario("Los campos FECHA_PEDIDO y CLIENTE_ID son obligatorios.");
                    break;

                case 1409:
                    e.setMensajeUsuario("El campo ESTADO no puede estar vacío.");
                    break;

                case 2290:
                    e.setMensajeUsuario("Uno de los valores ingresados es inválido. Verifique.");
                    break;

                case 2291:
                    e.setMensajeUsuario("El cliente seleccionado no existe. Verifique su información.");
                    break;

                case 12899:
                    e.setMensajeUsuario("Los detalles ingresados son demasiado largos.");
                    break;

                case 1064:
                    e.setMensajeUsuario("Ha habido un error de sintaxis consulte los formatos de inserción.");
                    break;

                case 60:
                    e.setMensajeUsuario("La base de datos está ocupada, intente más tarde.");
                    break;

                case 1040:
                    e.setMensajeUsuario("No se pueden realizar más conexiones a la base de datos.");
                    break;
                    
                case 20103:  
                    e.setMensajeUsuario("La sesión ha expirado o está en estado incorrecto.");
                    break;

                default:
                    e.setMensajeUsuario("Error general del sistema. Consulte Admin");
            }

            throw e; // Lanzar la excepción personalizada
        }
        return registrosAfectados;
    
    }
    
    /**
     * Lee un pedido específico de la base de datos.
     * 
     * @param pedidoID El ID del pedido a leer.
     * @return Un objeto Pedido con los datos recuperados, o null si no se encuentra.
     * @throws ExcepcionJuego Si ocurre un error de base de datos.
     */
    public Pedido leerPedido(Integer pedidoID) throws ExcepcionJuego {
        Pedido pedido = null;
        String dql = "SELECT p.PEDIDO_ID, p.FECHA_PEDIDO, p.FECHA_ENTREGA, p.ESTADO, p.DETALLES, " +
                     "c.CLIENTE_ID, c.NOMBRE " +
                     "FROM PEDIDO p " +
                     "JOIN CLIENTE c ON p.CLIENTE_ID = c.CLIENTE_ID " +
                     "WHERE p.PEDIDO_ID = ?";

        try (Connection conexion = DriverManager.getConnection(conexionBD, usuario, contraseña);
             PreparedStatement sentencia = conexion.prepareStatement(dql)) {

            // Establecer el parámetro de la sentencia SQL
            sentencia.setInt(1, pedidoID);

            try (ResultSet resultado = sentencia.executeQuery()) {
                if (resultado.next()) {
                    pedido = new Pedido();
                    pedido.setPedidoID(resultado.getInt("PEDIDO_ID"));
                    pedido.setFecha_pedido(resultado.getDate("FECHA_PEDIDO"));
                    pedido.setFecha_entrega(resultado.getDate("FECHA_ENTREGA"));
                    pedido.setEstado(resultado.getString("ESTADO"));
                    pedido.setDetalles(resultado.getString("DETALLES"));

                    Cliente cliente = new Cliente();
                    cliente.setClienteID(resultado.getInt("CLIENTE_ID"));
                    cliente.setNombre(resultado.getString("NOMBRE"));

                    pedido.setCliente(cliente);
                }
            }

        } catch (SQLException ex) {

            ExcepcionJuego e = new ExcepcionJuego();
            e.setMensajeAdmin(ex.getMessage());
            e.setSentenciaSQL(dql);
            e.setCodigoErrorBD(ex.getErrorCode());

            switch (ex.getErrorCode()) {
                case 942:  // Tabla o vista no existe
                    e.setMensajeUsuario("La tabla o vista PEDIDO no existe.");
                    break;
                case 1045:  // Acceso denegado
                    e.setMensajeUsuario("Acceso denegado a la base de datos. Verifique las credenciales.");
                    break;
                case 1722:  // Error de conversión de datos
                    e.setMensajeUsuario("Error al leer los datos del pedido. Verifique los valores.");
                    break;
                default:
                    e.setMensajeUsuario("Error al leer el pedido. Consulte con el administrador.");
                    break;
            }

            throw e;
        }

        return pedido;
    }
    
    /**
     * Lee todos los pedidos de la base de datos.
     * 
     * @return Una lista de objetos Pedido con los datos recuperados.
     * @throws ExcepcionJuego Si ocurre un error de base de datos.
     */
    public ArrayList<Pedido> leerPedidos() throws ExcepcionJuego{
        
        ArrayList<Pedido> listaPedidos = new ArrayList<>();
        Pedido pedido;
        Cliente cliente;
        String dql = "SELECT p.PEDIDO_ID, p.FECHA_PEDIDO, p.FECHA_ENTREGA, p.ESTADO, p.DETALLES, "
                + "c.CLIENTE_ID, c.NOMBRE "
                + "FROM PEDIDO p "
                + "JOIN CLIENTE c ON p.CLIENTE_ID = c.CLIENTE_ID";
        
        try {
            
            Connection conexion = DriverManager.getConnection(conexionBD, usuario, contraseña);
            Statement sentencia = conexion.createStatement();
            ResultSet resultado = sentencia.executeQuery(dql);
            
            while (resultado.next()) {
                
                pedido = new Pedido();
                pedido.setPedidoID(resultado.getInt("PEDIDO_ID"));
                pedido.setFecha_pedido(resultado.getDate("FECHA_PEDIDO"));
                pedido.setFecha_entrega(resultado.getDate("FECHA_ENTREGA"));
                pedido.setEstado(resultado.getString("ESTADO"));
                pedido.setDetalles(resultado.getString("DETALLES"));
                
                cliente = new Cliente();
                cliente.setClienteID(resultado.getInt("CLIENTE_ID"));
                cliente.setNombre(resultado.getString("NOMBRE"));
                
                pedido.setCliente(cliente);
                listaPedidos.add(pedido);
                
            }
            
            resultado.close();
            sentencia.close();
            conexion.close();
            
        } catch (SQLException ex) {
            
            ExcepcionJuego e = new ExcepcionJuego();
            e.setMensajeAdmin(ex.getMessage());
            e.setSentenciaSQL(dql);
            e.setCodigoErrorBD(ex.getErrorCode());
            
            switch (ex.getErrorCode()) {
                case 942:  // Tabla o vista no existe
                    e.setMensajeUsuario("La tabla o vista PEDIDO no existe.");
                    break;
                case 1045:  // Acceso denegado
                    e.setMensajeUsuario("Acceso denegado a la base de datos. Verifique las credenciales.");
                    break;
                case 1722:  // Error de conversión de datos
                    e.setMensajeUsuario("Error al leer los datos de los pedidos. Verifique los valores.");
                    break;
                default:
                    e.setMensajeUsuario("Error general al obtener los pedidos. Consulte con el administrador.");
                    break;
            }
            throw e;
        }
        return listaPedidos;
    }   
}
